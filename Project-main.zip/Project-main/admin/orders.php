
<?php 
  // Database
  include('../conn.php');
  
  // Set session
  session_start();
  if(isset($_POST['records-limit'])){
      $_SESSION['records-limit'] = $_POST['records-limit'];
  }
  

  $limit = isset($_SESSION['records-limit']) ? $_SESSION['records-limit'] : 10;
  $page = (isset($_GET['page']) && is_numeric($_GET['page']) ) ? $_GET['page'] : 1;
  $paginationStart = ($page - 1) * $limit;
  $authors = $connection->query("SELECT * FROM orders  LIMIT $paginationStart, $limit")->fetchAll();

  // Get total records
  $sql = $connection->query("SELECT count(id) AS id FROM orders ;")->fetchAll();
  $allRecrods = $sql[0]['id'];
  
  // Calculate total pages
  $totoalPages = ceil($allRecrods / $limit);

  // Prev + Next
  $prev = $page - 1;
  $next = $page + 1;

  include "sidenav.php";
include "topheader.php";
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <div class="col-md-14">
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Orders  / Page </h4>
              </div>
              <div class="card-body">
                             
        <!-- Datatable -->
        <table class="table table-bordered table-striped mb-6" id="myTable">
            
            <thead>
                <tr class="table-success" style="background-color: #148bff;">
                <th scope="col">#Order ID</th>
                   
                    <th scope="col">Date</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total Amount</th>
                    <th scope="col">Status</th>
                   
                </tr>
            </thead>
            <tbody>
                <?php foreach($authors as $author): ?>
                <tr>
                <td><?php echo $author['id']; ?></td>
                   
                    <td><?php echo $author['date']; ?></td>
                    <td><?php echo $author['product_title']; ?></td>
                    <td><?php echo $author['price'].'$'; ?></td>
                    <td><?php echo $author['qty']; ?></td>
                    <td><?php echo $author['total_amount'].'$'; ?></td>
                    <td><?php echo $author['status']; ?></td>
              
                  
                      
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
         
              </div>
            </div>
          </div>
          
        </div>
      </div>
      <?php
include "footer.php";
?>